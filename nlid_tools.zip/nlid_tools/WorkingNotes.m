% development notes 
%
- third order corredation is not working
%%
1) Class parameters will be capitalized at the first letter and for each word.
2) This is a change

Classes updated:
nltop
    nldat
    nlm
    param
    cor
    irf
    polynom
    2011-06-11 fresp, pdf
    2011-06-15 spect
    2011-

