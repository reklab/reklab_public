function i=nlmtst(i)
%
% test of nlbl identification
%
z=rand(10,10);
i=wkern(z);
plot (i);
% wkern/nlmtst

% Copyright 1999-2003, Robert E Kearney and David T Westwick
% This file is part of the nlid toolbox, and is released under the GNU 
% General Public License For details, see ../copying.txt and ../gpl.txt 
