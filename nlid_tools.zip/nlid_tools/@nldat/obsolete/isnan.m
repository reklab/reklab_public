function y = isnan (x);
y=nldat(x);
y=isnan(double(x));
return
% nldat/isnan
% 11 Dec 2000 rek

% Copyright 1999-2003, Robert E Kearney
% This file is part of the nlid toolbox, and is released under the GNU 
% General Public License For details, see copying.txt and gpl.txt 
