function l = length (z)
% length functon for nlad objects
l = max(size(z));
return
% nldat/length

% Copyright 1999-2003, Robert E Kearney
% This file is part of the nlid toolbox, and is released under the GNU 
% General Public License For details, see copying.txt and gpl.txt 
