function  nlmtst( X )
%UNTITLED Test opweration of nldat objects 
%   Detailed explanation goes here
nldatDemo