function qtext = quote (text)
qtext = [ '''' text '''' ];
return
