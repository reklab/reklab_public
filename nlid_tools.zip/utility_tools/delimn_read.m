function dlim_read  = csv_read ( fname, delim ) 
lun=fopen (fname);
l=fgelt(lun);
disp(l); 

