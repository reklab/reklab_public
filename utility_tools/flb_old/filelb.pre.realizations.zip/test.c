main()
{
#  include <stdlib.h>
#  include "/usr_reflex/local2/ictools/usrlibs/debug.h"
#  include "stdio.h"
#  include "math.h"
#  include "sys/file.h"
#  include "string.h"
#  include "filelb.h"
#  include "unistd.h"

   extern INT_T read_flb_details ( FILE *, FLB_DETAILS *); 

  INT_T flb_flag;
  FILE *mat_ptr, *flb_ptr;
  FLB_DETAILS details;

   printf("test\n");
    if((flb_ptr=fopen ('test.flb', "rb"))== NULL){
      printf("Error opening FLB file: \n ");

   }

     flb_flag=read_flb_details (flb_ptr, &details);
   printf ("flb_fag = %i\n", flb_flag);
 }
