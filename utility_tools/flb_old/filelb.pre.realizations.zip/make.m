% make flbtomat
echo on
clear
delete flbtomat.dll
delete mattoflb.dll
mex flbtomat.c flb_io.c 
mex mattoflb.c flb_io.c
option=input_l('Install filelb mex files ','y')
if option,
  echo on
  !delete ..\*.dll
  !move *.dll ..
  echo off
end