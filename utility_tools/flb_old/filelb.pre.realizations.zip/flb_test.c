#include "/usr_reflex/local2/matlab4/extern/include/mex.h"

int mexFunction ( nlhs, plhs, nrhs, prhs)
     int nlhs;
     Matrix *plhs[];
     int nrhs;
     Matrix *prhs[];

{
  double x, *p;
  double *pr;
  double *i;
}

