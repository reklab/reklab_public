/* 
  mattoflb - mex file to store matlab files as ultrix filelb files
 
18 Dec 92 REK Modify help output
25 May 93 JAD Add binary matrix -to- bitmap option
20 Feb 94 REK Fix bad definitions of flb_ptr for alpha version
22 May 97 REK changes for matlabv5
15 Sep 98 GC  (V02-02) Fixed write_flb_r4 to use the mxGetPr() to find the
              start of the numeric array's real data area and use this pointer
              when writing data into the array.
*/

void mattoflb_help ( void);

#include <stdlib.h> 
#include <mex.h>
#include <math.h> 
#include <stdio.h>
#include <string.h>
#include "filelb.h"

#define FLB_NAME prhs[0]
#define X_MAT  prhs[1]
#define OPTIONS  prhs[2]
#define X_COMMENT prhs[3]
#define X_INCREMENT prhs[4]
#define X_DOMAIN   prhs[5]
#define X_NAMES prhs[6]
#define X_START prhs[7]

/* Some defines used by write_flb_bitmap */
#define BITMAP  (-1)		/* used to specify details.format field */
				/* == -sizeof(BYTE), by the way         */
#define BYTE	unsigned char
#define LSBit	1
#define	MSBit	(1<<7)
  
void mexFunction  (nlhs, plhs, nrhs, prhs)
     int nlhs;
     int nrhs;
     mxArray *plhs[];
     const mxArray  *prhs[];
{

  FILE *mat_ptr, *flb_ptr;
  FLB_DETAILS details;
  int num_rows, num_cols;
  int i,ic, j, chan, typ,row,nitems,col,iflag,header_size, result, flb_format;
  int *flb_data_i2;
  float *flb_data_r4, increment;
  
  double *mat_data;
  double min_x[8],max_x[8];
  char nam[128], *p, comment[128], flb_mode[4];
  char *mat_file, *flb_file, flb_file_name[128], options[128];
  
  int load_header();
  int write_flb_i4;
  void min_max_mat();
  void write_flb_details();

  char temp_chan_names[FLB_CHAN_MAX*FLB_NAME_MAX + 1];
 
 /* Set default values */

  strcpy (details.comment,"MATLAB matrix");
  strcpy (details.domain_name,"SAMPLE");
  strcpy (flb_mode,"ab");
  details.increment = 1.;
  details.format = 4;
  details.domain_start = 0.;
  for (i =0; i<8;i++) {  
    strcpy ( details.name[i],"Ch");
  }

  if (nrhs == 0) {
    mattoflb_help ();
    return;
  }

/* Handle options
     a - append to existing file (default)
     o - overwrite file
     r - store as 4byte reals
     i - store as 2 bye integers
     u - store as scaled 2 byte integers
     t - store as characters
     b - store binary matrix as bitmap

 */
  if ( nrhs >= 3) {
    if (! mxIsChar(OPTIONS) ) {
      mexErrMsgTxt ("Bad format for options");
    }
    mxGetString (OPTIONS, options, 128);

    if (strstr (options,"a") != '\0'){
      strcpy (flb_mode, "ab");
    }
    if (strstr (options,"r") != '\0'){
      details.format = 4;
    }
    if (strstr (options,"i") != '\0'){
      details.format = 2;
      }
    if (strstr (options,"u") != '\0'){
      details.format = -2;
      }
    if (strstr (options,"o") != '\0'){
      strcpy (flb_mode, "wb");
    }
    if (strstr (options,"b") != '\0'){
      details.format = BITMAP;
    }
  }

  /* Open FILELB file */
  if ( ! mxIsChar (FLB_NAME) ) {
    mexErrMsgTxt ("First parameter must be a file name\n");
  }
   flb_file= flb_file_name; 
   mxGetString (FLB_NAME, flb_file, 128);
 
  flb_file = flb_file_name;
  flb_ptr = fopen (flb_file, flb_mode);
  if (flb_ptr == NULL) {
    mexErrMsgTxt ("\nError opening FILELB file\n");
  }

  /* Get comment if present */
  if (nrhs >= 4) {
    if (! mxIsChar(X_COMMENT) ) {
      mexErrMsgTxt ("Comment parameter must be a string\n");
	}
    mxGetString ( X_COMMENT, details.comment, FLB_COMMENT_MAX);
  }

  /* Get increment */
  if (nrhs >= 5) {
    details.increment = mxGetScalar(X_INCREMENT);
  }
  /* Domain name */
  if ( nrhs >= 6 ) {
    mxGetString (X_DOMAIN, details.domain_name, FLB_NAME_MAX);
  }
  /* Channel names */
  if ( nrhs >= 7 ) {
	num_rows = mxGetM(X_NAMES);
	num_cols = mxGetN(X_NAMES);
	mxGetString(X_NAMES,&temp_chan_names, num_rows*num_cols+1);

	for (i=0; i<(num_rows*num_cols); i++) {
		/* Copy the characters into details.name char by char. */
		details.name[i%num_rows][i/num_rows] = temp_chan_names[i];
	}
	for (i=0;i<num_rows; i++){
		/* Manually null terminate all the strings. */
		details.name[i][num_cols] = '\0';
    }
  }
  /* Domain start */
    if ( nrhs >= 8) {
      details.domain_start = mxGetScalar (X_START);
    }

  /* Read MATLAB header and data */

  if (mxIsChar(X_MAT) ) {
    details.format = 1;
  }  
  details.length=mxGetM(X_MAT);
  details.nchan= mxGetN(X_MAT);
  col = details.nchan;
  row = details.length;
  mat_data = mxGetPr(X_MAT);
  num_cols = col;
  if (details.nchan > FLB_CHAN_MAX ) {
   num_cols =1;
   printf ("mattoflb: MATLAB data has  many columns. Treating as an ensemble\n");
   }

  min_max_mat (mat_data, num_cols, row, details.min,details.max);
  write_flb_details (flb_ptr, &details);

  /* Do format conversion and store as FILELB files */

  flb_format = details.format;
 if (flb_format == 1){
    write_flb_b1 ( row, col, mat_data, flb_ptr);
  }
  else if (flb_format == 2){
    write_flb_i2 ( row, col, mat_data, flb_ptr);
  }
  else if (flb_format == -2){
    write_flb_u2 ( row, col, mat_data, flb_ptr, details.min, details.max);
  }
  else if (flb_format == 4){
    write_flb_r4 ( row, col, mat_data, flb_ptr);
  }
  else if (flb_format == BITMAP){
     write_flb_bitmap ( row, col, mat_data, flb_ptr);
  }
  fclose(flb_ptr);
}

/* {{{ write_flb_r4  */

int  write_flb_r4 (row, col, mat_data, flb_ptr )
     double *mat_data;
     FILE  *flb_ptr;
     int row, col;
     
{
  float  *flb_data, *pflb_data;
  int chan,i,k, dim[2];
  int flb_format, nitems;
  dim[0]=row;
  dim[1]=col;
  flb_format =4;
  flb_data =  mxCreateNumericArray (2, dim,  mxSINGLE_CLASS, mxREAL );

  /* Must get pointer to actual data area for reals. */
  pflb_data = mxGetPr(flb_data);

  k=0;
  for (chan =0; chan < col; chan++) {
    /* Convert format */
    for (i=0; i<row; i++, k++) {
      pflb_data[i] = mat_data[k];
    }
    nitems=fwrite (pflb_data, flb_format, row, flb_ptr);
    if (nitems < row){
      mexErrMsgTxt ("Error writing R4data\n");
    }

  }
  mxDestroyArray (flb_data);
  return;
}

/* }}} */

/* {{{ write_flb_b1 */

int  write_flb_b1 (row, col, mat_data, flb_ptr )
     
     double *mat_data;
     FILE *flb_ptr;
     int row, col;
     
{
  char  *flb_data;
  int chan,i,k, flb_format, dim[2];
  flb_format = 1;
  dim[0]=row;
  dim[1]=col;
  flb_data = (char *) mxCreateNumericArray(2,dim,mxUINT8_CLASS, mxREAL);
  k=0;
  for (chan =1; chan <= col; chan++) {
   
    /* Convert format */
    for (i=0; i<row; i++) {
      *(flb_data+i) = *(mat_data+k);
      k++;
    }
    fwrite (flb_data, row, flb_format, flb_ptr);
  }
  mxDestroyArray (flb_data);
  return;
}

/* }}} */


/* {{{ write_flb_i2  */

int  write_flb_i2 (row, col, mat_data, flb_ptr )
     
     double *mat_data;
     FILE *flb_ptr;
     int row, col;
     
{
  double x;
  short int  *flb_data;
  int chan,i,k, nitems, dim[2];
  int flb_format;
  dim[0]=row;
  dim[1]=col;
  flb_format = 2;
  flb_data = (short int *) mxCreateNumericArray (2, dim, mxINT16_CLASS, mxREAL);
  k=0;
  for (chan =0; chan < col; chan++) {
    /* Convert format */
    for (i=0; i<row; i++) {
      *(flb_data+i) =   *(mat_data+k) ; 
       k++;
     }
    nitems= fwrite (flb_data, row, flb_format, flb_ptr);
  }
  mxDestroyArray (flb_data);
  return;
}

/* }}} */


/* {{{ write_flb_u2 */

int  write_flb_u2 (row, col, mat_data, flb_ptr, min_x, max_x)

     /* Write data as scaled 2 byte integers */
     double *mat_data;
     FILE *flb_ptr;
     int row, col;
     double *min_x, *max_x;
     
{
  double  scale, xtemp;
  int flb_format, nitems, dim[2] ;
  unsigned short int  *flb_data;
  int chan,i, j,k ;
  dim[0]=row;
  dim[1]=col;
  flb_format = 2;
  flb_data = (unsigned short int *) mxCreateNumericArray (2,dim,
         mxUINT16_CLASS, mxREAL);
  /* Convert format */ 
  k=0;
  for (chan =0; chan < col; chan++) {
    scale = ((double) UNSIGNED_SHORT_MAX)/((*(max_x+chan))-*(min_x+chan));
    
    for (i=0; i<row; i++) {
      xtemp =(*(mat_data+k) - *(min_x+chan)) *scale;
      *(flb_data+i)=(unsigned short int ) xtemp;
      k++;
    }
    nitems = fwrite (flb_data, row, flb_format, flb_ptr);
  }
  mxDestroyArray(flb_data);
  return;
}

/* }}} */

int write_flb_bitmap (row, col, mat_data, flb_ptr)
/* Write a binary matrix as a bitmap */

   int row, col;     	/* dimensions of matrix */
   double *mat_data;  	/* matrix entries (1 or 0 in our case) */
   FILE *flb_ptr;     	/* I have *no* idea why the rest of the code */
                      	/* has this as an "int" instead of "FILE*"   */
{
   unsigned long i=0,	      /* index variable */
            size = row*col;   /* total number of entries */

   BYTE bit,		/* (mask) points to a single bit within byteme */
 	byteme;		/* buffer to hold byte before it is written out */
 
   /* now build the bitmap, one byte at a time, by stepping "bit"     */
   /* through each successive bit value, and ORing this with "byteme" */
   /* to turn on each bit as required...                              */
   /* Achtung:  Note that if the matrix is NOT binary, the routine    */
   /* will not complain, but will quietly convert all values >0  to   */
   /* 1's in the bitmap!  In other words, GIGO.                       */

   while( i<size ){
      bit = (BYTE)LSBit;	/* start at first bit */
      byteme = (BYTE)0;		/* start with clean byte */

      while( bit && (i<size)){	/* is byte filled (bit==0), or out of data? */
         byteme |= (BYTE)( (mat_data[i++] >0) ? bit:0 );
         bit <<= 1;        	/* on to the next bit */
      }

      putc(byteme, flb_ptr);	/* write this byte to file */
   }  

   return;
}

void min_max_mat ( mat_data, col, row, min_x, max_x)
     double *mat_data, *min_x, *max_x;
     int col, row;
{
  int i,j,k;
  k =0;
  for (i=0; i < col; i++){
    *(min_x+i) = *(mat_data+k);
    *(max_x+i) = *(mat_data+k);
    for (j=0; j < row; j++){
      if ( *(mat_data+k) > *(max_x+i)) *(max_x+i)= *(mat_data+k);
      if ( *(mat_data+k) < *(min_x+i)) *(min_x+i)= *(mat_data+k);
      k++;
    }
  }
}
  
  
void mattoflb_help ( )
      
{
  printf("\nmattoflb V02-02 (matlab-v)  REK\n");
  printf("\n\t Store matlab files as  filelb files\n");
  printf("\n  usage: mattoflb ( f, x, o, c, i, d, n, s )\n");
  printf("\t f - name of filelb file\n");
  printf("\t x - matrix to store\n");
  printf ("\t [o] - option string\n");
  printf ("\t\t [a]      : append to existing file (default)\n");
  printf ("\t\t [i]      : store as 2 byte integers \n");
  printf ("\t\t [u]      : store as scale 2 byte integers \n");
  printf ("\t\t [r]      : store as 4 byte reals (default) \n");
  printf ("\t\t [t]      : store as string \n");
  printf ("\t\t [b]      : store binary matrix as bitmap \n");
  printf ("\t\t [o]      : overwrite existing file \n");
  printf ("\t [c] - comment string\n");
  printf ("\t [i] - domain increment\n");
  printf ("\t [d] - domain name\n");
  printf ("\t [n] - channel names\n");
  printf ("\t [s] - domain start\n");
  printf ("\n Only  the filename and matrix paramters are mandatory\n");
  printf (" HELP is dislayed if flbtomat is called with no parameters\n");
}



























