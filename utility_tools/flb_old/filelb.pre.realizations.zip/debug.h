/* debugging printf aids... adapted from Dr Bob's Utilities */

#ifndef __debug_h

#define COMMA ,

#define DEBUG_LOC(name) DEBUG_PRN("DEBUG LOC-->  %s : %s : line %d\n"  \
        COMMA __FILE__ COMMA name COMMA __LINE__)

#ifndef debug
#    define DEBUG(msg) /* nothing */
#    define DEBUG_PRN(stuff) /* nothing */
#    define NODEBUG(stuff) stuff
#    define NODEBUG_PRN(msg) fprintf(stderr,msg); fflush(stderr) 
#else
#    define DEBUG_PRN(msg) fprintf(stderr,msg); fflush(stderr) 
#    define DEBUG(stuff) stuff
#    define NODEBUG(msg) /* nothing */
#    define NODEBUG_PRN(stuff) /* nothing */
#endif


#endif
