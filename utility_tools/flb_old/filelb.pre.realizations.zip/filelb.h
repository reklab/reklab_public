/*  
  filelb.h =- header which defines the file header strucutre for
  cases having one or four channels
  15 Mar 94 REK Chan FLB_CHAN_MAX to 32
*/

#include "flbport.h"

#define UNSIGNED_SHORT_MAX  MAX_VAL(unsigned short) 
#define FILELB_VERSION_NUM 2
#define FLB_CHAN_MAX 64
#define FLB_NAME_MAX 80
#define FLB_COMMENT_MAX 512
typedef	struct {
	QUARTET version_num;
	QUARTET nchan;
	QUARTET length;
	QUARTET format;
	char domain_name[ FLB_CHAN_MAX];
	float increment;
	float domain_start;
	char comment[ FLB_COMMENT_MAX];
	char name[ FLB_CHAN_MAX][FLB_NAME_MAX];
	double min[FLB_CHAN_MAX];
	double max[FLB_CHAN_MAX];
} FLB_DETAILS ;







