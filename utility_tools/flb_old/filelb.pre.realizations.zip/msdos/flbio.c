/* flb_io.c */

#ifdef MSDOS			/* DOS port needs different headers */
#  include <stdio.h>
#  include <string.h>
#  include "filelb.h"
#  include <math.h>
#  include "debug.h"

 /* forward declarations, because Turbo-C emulates a */
 /* typical brain-damaged Pascal Compiler...         */

  INT_T read_vms_flb_details ( FILE *, FLB_DETAILS * );
  INT_T read_flb_details ( FILE *, FLB_DETAILS *); 
  void write_flb_details ( FILE *, FLB_DETAILS *); 

#else
#  include "sys/file.h"
#  include "stdlib.h"
#  include "stdio.h"
#  include "string.h"
#  include "filelb.h"
#  include "unistd.h"
#  include "/usr/local2/ictools/usrlibs/debug.h"
#endif

void write_flb_details ( flb_ptr, details )

     FILE  *flb_ptr;
     FLB_DETAILS *details;
{

  QUARTET string_len, vnum;
  INT_T i, num_names;

  vnum = 2;
  fwrite (&vnum, sizeof(QUARTET), 1, flb_ptr);
  fwrite (&(details->nchan), sizeof(QUARTET), 1, flb_ptr);
  fwrite (&(details->length), sizeof(QUARTET), 1, flb_ptr);
  fwrite (&(details->format), sizeof(QUARTET), 1, flb_ptr);
  string_len = strlen (details->domain_name);
  fwrite (&string_len, sizeof(QUARTET), 1, flb_ptr);
  fwrite ((details->domain_name), sizeof(char), string_len, flb_ptr);
  fwrite (&(details->increment), sizeof(float), 1, flb_ptr); 
  fwrite (&(details->domain_start), sizeof(float), 1, flb_ptr);
  string_len = strlen (details->comment);
  fwrite (&string_len, sizeof(QUARTET), 1, flb_ptr);
  fwrite ((details->comment), sizeof(char), string_len, flb_ptr);
  if (details->nchan > FLB_CHAN_MAX) {
    num_names = 1;
    }
  else {
    num_names = details->nchan;
  }
  for (i=0; i < num_names; i++){
    string_len = strlen (details->name[i]);
    fwrite (&string_len, sizeof(QUARTET), 1, flb_ptr);
    fwrite ((details->name[i]), sizeof(char),string_len, flb_ptr);
  }
  fwrite ((details->min), sizeof (double), num_names, flb_ptr);
  fwrite ((details->max), sizeof (double), num_names, flb_ptr);
  return;
}



INT_T read_flb_details ( flb_ptr, details )

     FILE  *flb_ptr;
     FLB_DETAILS *details;
{

  QUARTET string_len;
  INT_T i, num_names;

  if(fread (&(details->version_num), sizeof(QUARTET), 1, flb_ptr) != 1) {
    return -1;
      };

  DEBUG(
	printf("\n");
  	DEBUG_LOC("read_flb_details");
        printf("details->version_num = %d\n\n" COMMA details->version_num); 
  )

  if (details->version_num == 1) {
    read_vms_flb_details ( flb_ptr, details );
  }
  else if (details->version_num ==2){
    fread (&(details->nchan), sizeof(QUARTET), 1, flb_ptr);
    fread (&(details->length), sizeof(QUARTET), 1, flb_ptr);
    fread (&(details->format), sizeof(QUARTET), 1, flb_ptr);
    fread (&string_len, sizeof(QUARTET), 1, flb_ptr);
    if (string_len > FLB_NAME_MAX) {
      printf ("Domain name too long: %s\n", details->domain_name);
      exit ();
    }

    fread ((details->domain_name), sizeof(char), string_len, flb_ptr);
    details->domain_name[string_len] = '\0';
    fread (&(details->increment), sizeof(float), 1, flb_ptr); 
    fread (&(details->domain_start), sizeof(float), 1, flb_ptr);
    fread (&string_len, sizeof(QUARTET), 1, flb_ptr);
    if (string_len > FLB_COMMENT_MAX) {
      printf ("Comment too long: %s\n", details->comment);
      exit ();
    }
    fread ((details->comment), sizeof(char), string_len, flb_ptr);
    details->comment[string_len]= '\0';
    if (details->nchan > FLB_CHAN_MAX) {
      num_names = 1;
      }
    else {
      num_names = details->nchan;
	}
    for (i=0; i < num_names; i++){
      fread (&string_len, sizeof(QUARTET), 1, flb_ptr);
      if (string_len > FLB_NAME_MAX) {
	printf ("Channel name too long: %s\n", details->name[i]);
	exit ();
      }
      fread ((details->name[i]), sizeof(char), string_len, flb_ptr);
    details->name[i][string_len] = '\0';
    }
    fread ((details->min), sizeof (double), num_names, flb_ptr);
    fread ((details->max), sizeof (double), num_names, flb_ptr);
  }
  else {
    printf ("Bad FLB version number\n");
    exit();
  }
  return 1;
}




INT_T read_vms_flb_details ( flb_ptr, details )

     FILE  *flb_ptr;
     FLB_DETAILS *details;
{
  INT_T i, count;

  fread (&(details->nchan), sizeof(QUARTET), 1, flb_ptr);
  fread (&(details->length), sizeof(QUARTET), 1, flb_ptr);
  if (details->nchan > 1 ) {
    fseek ( flb_ptr, 4*(details->nchan -1), SEEK_CUR);
  }
  fread (&(details->format), sizeof(QUARTET), 1, flb_ptr);
  if (details->nchan > 1 ) {
    fseek ( flb_ptr, 4*(details->nchan -1), SEEK_CUR);
  }
  fread ((details->domain_name), 8, 1, flb_ptr);
  details->domain_name[8]= '\0';
  if (details->nchan > 1 ) {
    fseek ( flb_ptr, 8*(details->nchan -1), SEEK_CUR);
  }
  fread (&(details->increment), sizeof(float), 1, flb_ptr); 
  if (details->nchan > 1 ) {
    fseek ( flb_ptr, 4*(details->nchan -1), SEEK_CUR);
  }

  fread (&(details->domain_start), sizeof(float), 1, flb_ptr);
   if (details->nchan > 1 ) {
    fseek ( flb_ptr, 4*(details->nchan -1), SEEK_CUR);
  }

  fseek ( flb_ptr, 4* details->nchan, SEEK_CUR);
  for (i=0; i< details->nchan; i++){
    fread (details->name[i], 1,16, flb_ptr);
    details->name[i][16] = '\0';
  }
  fread (details->comment, sizeof(char), 80, flb_ptr);
  details->comment[79]='\0';
  count = 88 + (details->nchan)*44;
  fseek ( flb_ptr, 512-count, SEEK_CUR);
  return;
}


