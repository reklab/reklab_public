/* flbport.h
 * Definitions which strive for at least SOME degree
 * of machine-independence, for easier porting of 
 * the filelb progs. to alien OS's (like Messy-DOS) 
 */

#ifndef __flbport_h
# define __flbport_h


# define    LONG_T       long int
# define    INT_T        int

/* use this macro when you want to assign a "big" number, or */
/* specifically want to refer to the largest value a number  */ 
/* of type "n" can hold...                                   */
/* CRUFTY HACK ALERT:  Note that the non-MSDOS version only  */
/* works on UNSIGNED numbers, because it employs a horrible  */
/* hack; but that's the only way I could get it to work on   */
/* 4-byte ints; the DOS version was rejected by gcc...       */
/* If you come up with a better sol'n, please use it!!       */

# ifdef MSDOS
#   define MAX_VAL(n)	 (( (n)1 << (8*sizeof(n)) ) -1 )
# else
#   define MAX_VAL(n)	 (n)(-1)       /* <-- yuk! */
# endif

/* The original mattoflb wrote INTs to file, but INTS on the MIPS *
 * were 4 bytes... to be able to read them back, Borland TCC must *
 * use long ints:                                                 */

# ifdef MSDOS                      
#   define QUARTET	long int 
# else
#   define QUARTET	int 
# endif

/* why 'quartet'?  A spoof on the ISO (and french) "octet" :) */


#endif
