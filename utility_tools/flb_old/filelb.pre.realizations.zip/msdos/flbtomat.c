/* 
     flbtomat - mex file convert flb files to mat files
     
Options:
[  x, comment, names, domain, incr, start] = flbtomat (file, case, option)

13 May 92  - close flb_ptr before calling mex_error.
14 May 92  - corrected close error - use fclose rather than close
18 Dec 92  - modify output format
25 May 93  - add bitmap -to- binary matrix extraction option
             (see mattoflb.c for complementary half) [jd.]
4  Aug 93  - Machine-independent version, and porting to MSDOS [jd.]
             (addition of "flbport.h", which defines machine-indep word sizes)
*/

#ifdef MSDOS			/* different headers for MSDOS */
#  include <stdio.h>
#  include <cmex.h>
#  include <math.h>
#  include <string.h>
#  include "filelb.h"
#  include "debug.h"

   /* forward declarations, for TurboC... */

   extern INT_T read_vms_flb_details ( FILE *, FLB_DETAILS * );
   extern INT_T read_flb_details ( FILE *, FLB_DETAILS *); 
   extern void write_flb_details ( FILE *, FLB_DETAILS *); 
   extern loadmat( FILE *,INT_T *,char *,INT_T *,INT_T *,INT_T *,double **,double **);
   extern savemat( FILE *,INT_T,char *,INT_T,INT_T,INT_T,double *,double *);
   extern INT_T load_header(FILE *,INT_T *,char *,INT_T *,INT_T *,INT_T *,INT_T *);
   extern void matc_str_cnv(char *,double *,INT_T);

   INT_T read_flb_case (FLB_DETAILS *, FILE *);
   INT_T read_vms_flb_case (FLB_DETAILS *, FILE *);
   INT_T skip_flb_case (FLB_DETAILS *, FILE *);
   INT_T skip_vms_flb_case (FLB_DETAILS *, FILE *);
   print_flb_header (FLB_DETAILS *, INT_T, INT_T);
   flbtomat_help (void); 

#else               /* headers for Unix, VMS, etc... */
#  include "/usr/local2/ictools/usrlibs/debug.h"
#  include "/usr/local/matlab/mex/cmex.h"
#  include "math.h"
#  include "sys/file.h"
#  include "stdio.h"
#  include "string.h"
#  include "filelb.h"
#  include "unistd.h"
#endif

#define FLB_NAME prhs [0]
#define CASE_NUM prhs [1]
#define OPTION   prhs [1]
#define Y_OUT plhs [0]
#define Y_COMMENT plhs [1]
#define Y_INCREMENT plhs [2]
#define Y_DOMAIN    plhs [3]
#define Y_NAMES     plhs [4]
#define Y_START     plhs [5]

/* Some defines used for bitmap conversion */
#define BITMAP	(-1)	/* for details.format identifier */
			/* == -sizeof(BYTE) by the way!  */
#define BYTE	unsigned char
#define LSBit	1
#define	MSBit	(1<<7)

unsigned QUARTET case_num; 
char vname[80];
float *flb_data;   /*  Array to hold data points */
char   *flb_data_char;
short  *flb_data_i2;
unsigned short int *flb_data_unsigned;
BYTE   *flb_data_byte;    
double *mat_data;

/* ------------------------------------------------------------------------
   flbtomat - main routine
   ------------------------------------------------------------------------
*/

user_fcn (nlhs, plhs, nrhs, prhs)

     INT_T  nlhs;
     INT_T nrhs;
     Matrix *plhs[];
     Matrix *prhs[];

{
  FILE *mat_ptr, *flb_ptr;
  FLB_DETAILS details;
  char *mat_file, *flb_file;
  char *temp[80], flb_file_name[80];
  double *comment,  domain[80];
  double scale, offset;
  double *d_case_num, *d_option;
  unsigned QUARTET input_case_num;
  INT_T i,j,k, itemp, length, name_len_max;
  INT_T  num_cases, type, mrows, ncols, imagf;
  INT_T col,row,col_offset, flb_index, mat_index, 
  display_flag, length_flag, output_flag, verbose_flag, case_flag;
  float *nn;
  double *mm, name[20], *increment, *yout, *p;
  
  input_case_num = MAX_VAL(unsigned QUARTET);
  display_flag = 0;
  verbose_flag = 2;
  output_flag = 1;
  length_flag =0; 
 if (nrhs == 0) {
    flbtomat_help ();
    return(0);
  }

  if (nlhs > 6 ) {
    mex_error ("Too many output channels specified\n");
    }

/*  Open filelb channel file */  	

    flb_file = flb_file_name;
    matc_str_cnv  (flb_file, FLB_NAME->pr, FLB_NAME->n);
    if((flb_ptr=fopen (flb_file, "rb"))== NULL){
      printf("Error opening FLB file:  %s\n ", flb_file);
      mex_error("Error opening FLB file");
    }

  /*  Case number */
    
  if (nrhs == 1) {
    display_flag = 1;
    output_flag = 0; 
    input_case_num = MAX_VAL(unsigned QUARTET);
    length_flag = 1;
  }
  
  if (nrhs == 2) {
    if ( OPTION->type == 1) {
      d_option = OPTION->pr;
      if ( (char) *d_option == 'v') {
	verbose_flag = 1;
	display_flag = 1;
	output_flag = 0;
	input_case_num = MAX_VAL(unsigned QUARTET);		
        length_flag=1;
      }
      if ( (char) *d_option == 'q') {
	display_flag = 0;
	output_flag =0;
	length_flag=1;
	input_case_num = MAX_VAL(unsigned QUARTET);		
      }
    }
    else {
      d_case_num = CASE_NUM->pr;
      input_case_num = ( INT_T ) *d_case_num;
    }
  }

  /* Read case header */

  DEBUG(   DEBUG_LOC("user_fcn");
	   printf("input_case_num = %u\n", input_case_num);
	)

  case_num = 0;
  while ((case_num<input_case_num)){
    case_num++;

  DEBUG(
	printf("\n");
	DEBUG_LOC("user_fcn");
	printf("case_num = %d\n", case_num);
  )

     if (read_flb_details (flb_ptr, &details)<0){
#ifdef MSDOS
      printf ("End of file\n");    /* TCC doesn't like fprintf w/ 1 arg */ 
#else
      fprintf("End of file\n");
#endif
      if ((output_flag == 1) & (length_flag == 0)){
	fclose(flb_ptr);
	mex_error ("Error reading flb file \n");
      }
      if (length_flag == 1){
	Y_OUT = create_matrix ( 1,1,REAL);
	*(Y_OUT->pr)=case_num-1;
      }

      return;
    }

    if (details.nchan > FLB_CHAN_MAX) {
#ifdef MSDOS
      printf ("flbtomat: FLB file has many channels. Treating as an enesemble\n");
#else
      fprintf ("flbtomat: FLB file has many channels. Treating as an enesemble\n");
#endif
     }   

    if (display_flag == 1) {
      print_flb_header(&details, case_num, verbose_flag);
      if (verbose_flag == 2) {
	verbose_flag =3;
      }
    }

    /* Read data and convert */
    if ((output_flag ==1 ) & (case_num == input_case_num)) {
      if (read_flb_case(&details, flb_ptr)<0){
	fclose (flb_ptr);
	mex_error ("Error reading data\n");
      }
    /* Convert to MATLAB double precision */
      length = details.length;
      mrows = length;
      ncols = details.nchan;
      Y_OUT = create_matrix ( mrows, ncols, REAL);
      mat_data = Y_OUT->pr;
      flb_index = 0;		/* index to step thru flb buffers */

      if (details.format == BITMAP){  
      /* Treat bitmapped data separately... */
      /* (because number of entries == number of BITS, not bytes) */

        /* first declare & define some very local variables */
        unsigned long  size = mrows*ncols,     /* know when to stop */
                          i = 0;               /* BIT index */

        BYTE bit,         		/* (mask) to check if 1 or 0 */
             byteme;                    /* buffer to hold current byte */

      /* this loop examines a byte at a time, and within that byte */
      /* looks at each bit in turn (by masking out the others)...  */
      /* Then decides whether the matrix entry should be a 1 or 0  */
      /* depending on whether the bit is set/reset.                */

        while( i<size ){
          byteme = flb_data_byte[flb_index++]; 	/* get new byte */
          bit = (BYTE)LSBit;			/* mask out first bit */
            
          while( bit && (i<size) ){   /* still on this bit and have data */
            mat_data[i++] = (double)( (byteme & bit) ? 1:0 ); 
            bit <<= 1; 			/* mask out next bit */
          }
        }
      }  /* end of BITMAP case */

      else{
      /* all other types of data are stored in multiples of one byte */

        for (col=0;col<ncols;col++) {
	  scale=(details.max[col]-details.min[col])/UNSIGNED_SHORT_MAX;
	  offset = details.min[col];
	  for (row=0;row<mrows;row++) {
	    mat_index = col*mrows + row;
	    if (details.format == 1) {
	      itemp  = *(flb_data_char + flb_index);
	      *(mat_data+mat_index) = (double) itemp;
	    }    
	    else if (details.format == 2) {
	      itemp  = *(flb_data_i2 + flb_index);
	      *(mat_data+mat_index) = (double) itemp;
	    }
	    else if (details.format == -2) {
	      itemp  = *(flb_data_unsigned + flb_index);
	      *(mat_data+mat_index) = ((double) itemp)*scale + offset;
	    }  
	    else if (details.format == 4) {
	      *(mat_data+mat_index) = *(flb_data + flb_index);
	    }             
	  flb_index++;;
	  } /* for row */
        }  /* for col */
      } /* end of else (not BITMAP) case */
      
      type =0;
      if (details.format == 1 ) Y_OUT->type = 1;
      if (details.format ==1) mex_free (flb_data_char);
      if (details.format ==2) mex_free (flb_data_i2);
      if (details.format ==-2) mex_free (flb_data_unsigned);
      else if (details.format ==4) mex_free (flb_data);
    } /* if output_flag==1 and case_num==input_case_num */

    else {
      skip_flb_case(&details, flb_ptr) ;
    }
  }

  /* Comment */

  if (nlhs >= 2) {
    mrows = 1;
    ncols =strlen(details.comment);
    Y_COMMENT = create_matrix ( mrows, ncols, REAL);
    Y_COMMENT->type = 1;
    comment = Y_COMMENT->pr;
    for (i=0;i< ncols; i++){
      *(comment+i) = details.comment[i];
    }
  }
  /* Domain increment */

  if (nlhs >= 3) {
    mrows = 1;
    ncols = 1;
    Y_INCREMENT = create_matrix ( mrows, ncols, REAL);
    increment = (Y_INCREMENT->pr);
    *increment = details.increment;
  }
  /* Domain name */
  if (nlhs >= 4) {
    ncols = strlen (details.domain_name);
    Y_DOMAIN = create_matrix (mrows, ncols, REAL );
    p = Y_DOMAIN->pr;
    Y_DOMAIN->type = 1;
    for (i=0;i<ncols;i++){
      *(p+i)= details.domain_name[i];
    }
  }
  /* Variable names */
  if (nlhs >= 5) {

    name_len_max = strlen (details.name[0]);
    for (i=0; i < details.nchan; i++) {
      if (strlen(details.name[i]) > name_len_max) {
	name_len_max=strlen(details.name);
      }
    }

    mrows = details.nchan;
    ncols=name_len_max;
    Y_NAMES = create_matrix (mrows, ncols, REAL );
    Y_NAMES->type =1 ;
    p = Y_NAMES->pr;
    k=0;
    for (j=0 ; j < name_len_max; j++){
      for (i=0; i < details.nchan; i++) {
	if (j <= strlen(details.name[i]))*(p+k) = details.name[i][j];
	else *(p+k)= '\0';
	k++;
      }
    }
  }
  /* Domain start */

  if (nlhs >= 6) {
    mrows = 1;
    ncols = 1;
    Y_START = create_matrix ( mrows, ncols, REAL);
    p = (Y_START->pr);
    details.domain_start= *p;
  }

/* End of file - close files and exit */
  fclose(flb_ptr);
  
}


/* ---------------------------------------------------------------------
   read_flb_case
  -----------------------------------------------------------------------*/

INT_T read_flb_case (details, flb_ptr)
     FLB_DETAILS *details;
     FILE *flb_ptr;

{

  INT_T i, j, nitems, nrec, n, nclose, nbytes, result, cf, cf_size;
  INT_T nsamp, chan;
  if (details->version_num == 1 ) {
    read_vms_flb_case ( details, flb_ptr);
  }
  else {
    cf = details->format;
    cf_size = cf;
    if (cf_size <0) cf_size = - cf_size;
    nsamp = details->nchan * details->length ;
    nbytes = nsamp *cf_size;
    if ( cf == 1) {
      flb_data_char = (char *) mex_calloc ( nsamp, cf_size );
      nitems=fread(flb_data_char, cf_size, nsamp, flb_ptr);
    }
    else if ( cf==2) {
      flb_data_i2 = (short *) mex_calloc ( nsamp, cf_size );
      nitems= fread(flb_data_i2, cf_size, nsamp, flb_ptr);
    }
    else if (cf==-2) {
      flb_data_unsigned=(unsigned short *) mex_calloc (nsamp, cf_size );
      nitems= fread(flb_data_unsigned, cf_size, nsamp, flb_ptr);
    }
    else if ( cf == 4) {
      flb_data = (float *) mex_calloc ( nsamp, cf_size );
      nitems= fread(flb_data, cf_size, nsamp,flb_ptr);
    }
    else if ( cf == BITMAP ){
       /* do a ceil(nsamp/8) because nsamp <--> number of BITS not bytes */
       nsamp = (INT_T)ceil((double)nsamp/8);

       flb_data_byte = (BYTE *) mex_calloc( nsamp, cf_size );
       nitems=fread(flb_data_byte,cf_size, nsamp, flb_ptr);
    }
    if (nitems != nsamp) {
        fclose(flb_ptr);
	mex_error ("Error reading input file\n");
    }
  }
} /* read_flb_case () */


/* ---------------------------------------------------------------------
   read_vms_flb_case
  -----------------------------------------------------------------------*/

INT_T read_vms_flb_case (details, flb_ptr)
     FLB_DETAILS *details;
     FILE *flb_ptr;
{
  INT_T cf, cf_size, nsamp, nbytes, nitems, off, i, remainder;
  cf = details->format;
  cf_size = cf;
  if (cf_size <0) cf_size = - cf_size;
  nsamp =  details->length ;
  nbytes = nsamp *cf_size;
  remainder = 512 - nbytes%512;
  off = 0;
  if (cf_size == 2) {
    flb_data_i2 = (short *) mex_calloc ( nsamp* details->nchan, cf_size );
  }
  else if (cf_size == 4) {
    flb_data = (float *) mex_calloc ( nsamp * details->nchan, cf_size);
  }
  for (i=0; i < details->nchan; i++){
    if ( cf == 1) {
      printf ("Format 1 not supported for VMS FLB files\n");
      exit();
    }
    else if ( cf==2) {
      nitems= fread(flb_data_i2+off, cf_size, nsamp, flb_ptr);
      if (remainder < 512) fseek (flb_ptr, remainder, SEEK_CUR);
    }
    else if (cf==-2) {
      printf ("Format -2 not supported for VMS FLB files\n");
      exit();
    }
    else if (cf==BITMAP){
      printf("Format BITMAP not supported for VMS FLB files\n");
      exit();
    }
    else if ( cf == 4) {
      nitems= fread(flb_data+off, cf_size, nsamp,flb_ptr);
      if (remainder < 512) fseek (flb_ptr, remainder, SEEK_CUR);
    }
    off = off + nsamp;
  }
  return;
}




/* ---------------------------------------------------------------------
   skip_flb_case
  -----------------------------------------------------------------------*/

INT_T skip_flb_case (details, flb_ptr)
     FLB_DETAILS *details;
     FILE *flb_ptr;

{

  QUARTET cf;
  LONG_T nbytes, cf_size, nsamp;

  if (details->version_num == 1 ) {
    skip_vms_flb_case ( details, flb_ptr);
  }
  else {
    cf = details->format;
    cf_size = cf;
    if (cf_size <0) cf_size = - cf_size;
    nsamp = details->nchan * details->length ;
    nbytes = nsamp *cf_size;

    DEBUG(	DEBUG_LOC("skip_flb_case");
		printf("cf_size = %d\n", cf);
		printf("nsamp   = %d\n", nsamp);
		printf("nbytes  = %d\n", nbytes);
         )

    if ( cf == 1) {
      fseek ( flb_ptr,  cf_size* nsamp, SEEK_CUR);
    }
    else if ( cf==2) {
           fseek ( flb_ptr,  cf_size* nsamp, SEEK_CUR);
    }
    else if (cf==-2) {
           fseek ( flb_ptr,  cf_size* nsamp, SEEK_CUR);    
    }
    else if (cf==BITMAP){
           nsamp = (INT_T)ceil((double)nsamp/8); /* divide byte count by 8 */
           fseek ( flb_ptr, cf_size*nsamp, SEEK_CUR);
    }
    else if ( cf == 4) {
      fseek ( flb_ptr,  cf_size* nsamp, SEEK_CUR);
    }
  }
}
/* read_flb_case () */


/* ---------------------------------------------------------------------
   skip_vms_flb_case
  -----------------------------------------------------------------------*/

INT_T skip_vms_flb_case (details, flb_ptr)
     FLB_DETAILS *details;
     FILE *flb_ptr;
{
  QUARTET cf;
  LONG_T cf_size, nsamp, nbytes, off, i, remainder;

  cf = details->format;
  cf_size = cf;
  if (cf_size <0) cf_size = - cf_size;
  nsamp =  details->length ;
  nbytes = nsamp *cf_size;
  remainder = 512 - nbytes%512;
  off = 0;
  for (i=0; i < details->nchan; i++){
    if ( cf == 1) {
      printf ("Format 1 not supported for VMS FLB files\n");
      exit();
    }
    else if ( cf==2) {
      fseek ( flb_ptr,  cf_size* nsamp, SEEK_CUR);
      if (remainder < 512) fseek (flb_ptr, remainder, SEEK_CUR);
    }
    else if (cf==-2) {
      printf ("Format -2 not supported for VMS FLB files\n");
      exit();
    }
    else if (cf==BITMAP){
      printf("Format BITMAP not supported for VMS FLB files\n");
      exit();
    }
    else if ( cf == 4) {
      fseek ( flb_ptr,  cf_size* nsamp, SEEK_CUR);
      if (remainder < 512) fseek (flb_ptr, remainder, SEEK_CUR);
    }
    off = off + nsamp;
  }
  return;
}

/* ---------------------------------------------------------------------- 
   print_flb_header
   ---------------------------------------------------------------------- */
print_flb_header (details,case_num, flag )
     FLB_DETAILS *details;
     INT_T case_num, flag;
{
  INT_T i, num_cols; 

  if ( flag == 1 ) {
    printf ("\nCase number = %d;",case_num);
    printf (" FLB Version: %d;",details->version_num);	
    printf (" Length: %d;",details->length);	
    printf (" Nchan: %d;",details->nchan);	
    printf (" Format: %d\n",details->format);	
    printf ("Comment: %s \n",details->comment);
    printf ("Domain Name: %s ;",details->domain_name);	
    printf (" Incr = %f ;",details->increment);
    printf (" Start= %f \n",details->domain_start);
    num_cols = details->nchan;
    if (num_cols > FLB_CHAN_MAX)
     num_cols =1;
    for (i=0; i< num_cols; i++) {
      printf ("Channel %i : Name = %s ; Min = %f ; max = %f\n", i, 
	      details->name[i], details->min[i], details->max[i]);
    }
  }
  else if ( flag ==2) {
    printf ("Case  NChan Length  Comment \n");
    printf ("%4d %4d %6d;",case_num, details->nchan,details->length);
    printf (" %s \n",details->comment);
  }
  else if ( flag ==3) {
    printf ("%4d %4d %6d;",case_num, details->nchan, details->length);
    printf (" %s \n",details->comment);
  }
}

flbtomat_help (void) 
{

DEBUG_LOC("Unix Compilation Trial 2");	/* for use with "debug.h" */

#ifdef MSDOS
  printf ("\nflbtomat v01-03 REK\t\t\tPCMATLAB version 1.0 JAD\n");
#else
  printf("\nflbtomat v01-03 REK\n");
#endif

printf ("\n convert FILELB files to MATLAB format\n");
printf ("\n  Usage:  [ x c i d n s]= flbtomat(file, case/ option");
printf ("\n outputs are: \n");
printf ("\t x - data\n");
printf ("\t c - comment\n");
printf ("\t i - increment\n");
printf ("\t s - domain start\n");
printf ("\t d - domain name\n");
printf ("\t d - channel name\n");
printf ("\t s - domain start\n");
printf ("\n inputs are: \n");
printf ("\t file - names of filelb file\n");
printf ("\t case - case to recall\n");
printf ("\t option  = v for verbose index\n");
printf ("\t option  = q for quit mode index\n");
printf ("\n Calling flbtomat with no parameters gives a help message\n");
printf ("\n Calling flbtomat with only the file name gives an index and");
printf ("\n and returns the number of cases in the file \n");

}

