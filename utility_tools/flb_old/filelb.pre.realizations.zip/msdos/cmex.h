/* 
 * CMEX.H - Include file for C-language MEX-files
 *
 * Copyright (c) The Mathworks, Inc. 1987
 * All Rights Reserved.
 *
 * Marc Ullman   June 11, 1987
 * revised: July 22, 1990	Added function prototypes
 */

#include <stddef.h>

/*
 * Matrix definition
 */
typedef struct mat {
	char *name;		/* pointer to char matrix name	 */
	int type;		/* variable type (1=text)	 */
	unsigned int m;		/* row dimension		 */
	unsigned int n;		/* column dimension		 */
	double *pr;		/* pointer to real matrix	 */
	double *pi;		/* pointer to imaginary matrix 	 */
} Matrix;

#define TEXT   1			/* mat.type indicating text	 */
#define MATRIX 0			/* mat.type indicating matrix	 */

#define REAL    0
#define COMPLEX 1

#define malloc(N)	mex_calloc(N,1)
#define calloc(N,S)	mex_calloc(N,S)
#define free(P)		mex_free(P)
#define	printf		mex_printf

#define	create_real_array(N)	(double *) mex_calloc((N),sizeof(double))
#define	create_int_array(N)	(int *) mex_calloc((N),sizeof(int))

extern	Matrix	*create_matrix(int, int, int);
extern	void	free_matrix(Matrix *);
extern	char	*mex_calloc(size_t, size_t);
extern	void	mex_free(void *);
extern	Matrix	*get_global(const char *);
extern	int	matlab_fcn(int, Matrix **, int, Matrix **, char *);
extern	void	matlab_trap(int);
extern	void	mex_error(const char *);
extern	int	heap_check(void);
extern	void	mex_printf(const char *, ...);
