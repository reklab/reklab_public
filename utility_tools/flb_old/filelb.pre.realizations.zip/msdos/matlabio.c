/*
 * loadmat - C language routine to load a matrix from a MAT-file.
 *
 * Here is an example that uses 'loadmat' to load a matrix from a MAT-file:
 *
 *      FILE *fp;
 *      char name[20];
 *      INT_T type, mrows, ncols, imagf;
 *      double *xr, *xi;
 *      fp = fopen("foo.mat","rb");
 *      loadmat(fp, &type, name, &mrows, &ncols, &imagf, &xr, &xi);
 *      fclose(fp);
 *      free(xr);
 *      if (imagf) free(xi);
 *
 * The 'loadmat' routine returns 0 if the read is successful and 1 if
 * and end-of-file or read error is encountered.  'loadmat' can be called
 * repeatedly until the file is exhausted and an EOF is encountered.
 *
 * Author J.N. Little 11-3-86
 */

#include "flbport.h"
#include <stdio.h>

typedef struct {
     long type;   /* type */
     long mrows;  /* row dimension */
     long ncols;  /* column dimension */
     long imagf;  /* flag indicating imag part */
     long namlen; /* name length (including NULL) */
} Fmatrix;

loadmat(fp, type, pname, mrows, ncols, imagf, preal, pimag)
FILE *fp;       /* File pointer */
INT_T *type;      /* Type flag: see reference section of guide */
INT_T *mrows;     /* row dimension */
INT_T *ncols;     /* column dimension */
INT_T *imagf;     /* imaginary flag */
char *pname;    /* pointer to matrix name */
double **preal;  /* pointer to real data */
double **pimag;  /* pointer to imag data */
{
	Fmatrix x;
	INT_T mn, namlen;

	/*
	 * Get Fmatrix structure from file
	 */
	if (fread((char *)&x, sizeof(Fmatrix), 1, fp) != 1) {
		return(1);
	}
	*type = x.type;
	*mrows = x.mrows;
	*ncols = x.ncols;
	*imagf = x.imagf;
	namlen = x.namlen;
	mn = x.mrows * x.ncols;

	/*
	 * Get matrix name from file
	 */
	if (fread(pname, sizeof(char), namlen, fp) != namlen) {
		return(1);
	}

	/*
	 * Get Real part of matrix from file
	 */
	if (!(*preal = (double *)malloc(mn*sizeof(double)))) {
		printf("\nError: Variable too big to load\n");
		return(1);
	}
	if (fread(*preal, sizeof(double), mn, fp) != mn) {
		free(*preal);
		return(1);
	}

	/*
	 * Get Imag part of matrix from file, if it exists
	 */
	if (x.imagf) {
		if (!(*pimag = (double *)malloc(mn*sizeof(double)))) {
			printf("\nError: Variable too big to load\n");
			free(*preal);
			return(1);
		}
		if (fread(*pimag, sizeof(double), mn, fp) != mn) {
			free(*pimag);
			free(*preal);
			return(1);
		}
	}
	return(0);
}

/*
 * savemat - C language routine to save a matrix in a MAT-file.
 *
 * Here is an example that uses 'savemat' to save two matrices to disk,
 * the second of which is complex:
 *
 *      FILE *fp;
 *      double xyz[1000], ar[1000], ai[1000];
 *      fp = fopen("foo.mat","wb");
 *      savemat(fp, 2000, "xyz", 2, 3, 0, xyz, (double *)0);
 *      savemat(fp, 2000, "a", 5, 5, 1, ar, ai);
 *      fclose(fp);
 *
 * Author J.N. Little 11-3-86
 */



savemat(fp, type, pname, mrows, ncols, imagf, preal, pimag)
FILE *fp;       /* File pointer */
INT_T type;       /* Type flag: Normally 0 for PC, 1000 for Sun, Mac, and  */
		/* Apollo, 2000 for VAX D-float, 3000 for VAX G-float    */
		/* Add 1 for text variables.     */
		/* See LOAD in reference section of guide for more info. */
INT_T mrows;      /* row dimension */
INT_T ncols;      /* column dimension */
INT_T imagf;      /* imaginary flag */
char *pname;    /* pointer to matrix name */
double *preal;  /* pointer to real data */
double *pimag;  /* pointer to imag data */
{
	Fmatrix x;
	INT_T mn;

	x.type = type;
	x.mrows = mrows;
	x.ncols = ncols;
	x.imagf = imagf;
	x.namlen = strlen(pname) + 1;
	mn = x.mrows * x.ncols;

	fwrite(&x, sizeof(Fmatrix), 1, fp);
	fwrite(pname, sizeof(char), (INT_T)x.namlen, fp);
	fwrite(preal, sizeof(double), mn, fp);
	if (imagf) {
	     fwrite(pimag, sizeof(double), mn, fp);
	}
}




INT_T load_header(fp, type, pname, mrows, ncols, imagf, header_size)

FILE *fp;       /* File pointer */
INT_T *type;      /* Type flag: see reference section of guide */
INT_T *mrows;     /* row dimension */
INT_T *ncols;     /* column dimension */
INT_T *imagf;     /* imaginary flag */                       
char *pname;    /* pointer to matrix name */
INT_T *header_size;
{
	Fmatrix x;
	INT_T namlen;

	/*
	 * Get Fmatrix structure from file
	 */
	if (fread((char *)&x, sizeof(Fmatrix), 1, fp) != 1) {
		return(1);
	}
	*type = x.type;
	*mrows = x.mrows;
	*ncols = x.ncols;
	*imagf = x.imagf;
	namlen = x.namlen;

	/*
	 * Get matrix name from file
	 */
	if (fread(pname, sizeof(char), namlen, fp) != namlen) {
		return(1);
	}

	*(header_size) = sizeof(Fmatrix)+namlen*sizeof(char);
	return(0);
}

void matc_str_cnv (  c, x, n )

/* Convert a MATLAB string to a C string */
     char  *c;
     double *x;
     INT_T n;

{

  INT_T i;
  for (i=0; i < n ; i++){
    *(c+i) = (char) *(x+i);
  }
  *(c+i) = '\0';
}


